function Settings() {
    return (
      <div>
        <h1 className="text-3xl font-bold mb-4">Settings</h1>
        <p className="text-gray-600">Your settings page content goes here.</p>
      </div>
    );
  }
  
  export default Settings;